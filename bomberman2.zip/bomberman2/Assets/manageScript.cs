﻿using UnityEngine;
using System.Collections;
using UnityEngine.UI;  

public class manageScript : MonoBehaviour {
	public GameObject text; 
	UnityEngine.UI.Text score;
	// Use this for initialization
	void Start () {
		score = text.GetComponent<Text>();

		if ((movement1.dead == 1) && (movement2.dead == 1)) {
			score.text ="Draw"; 
		}
		if ((movement1.dead == 0) && (movement2.dead == 1)) {
			score.text ="P1: Win";
		}
		if ((movement1.dead == 1) && (movement2.dead == 0)) {
			score.text ="P2: Win";
		}
	
	}
	
	// Update is called once per frame
	void Update () {
	
	}

	public void restart(){
		Application.LoadLevel (0);  
	}
}
