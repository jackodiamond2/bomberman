﻿using UnityEngine;
using System.Collections;


public class destruct_script : MonoBehaviour {
	public GameObject pickup1,pickup2,pickup3,pickup4;  
	// Use this for initialization
	void Start () {
	
	}
	
	// Update is called once per frame
	void Update () {
		  
	}
	 
	private void OnCollisionEnter(Collision collision)
	{
		
		// You probably want a check here to make sure you're hitting a zombie
		// Note that this is not the best method for doing so.
		if ( collision.gameObject.tag == "blast" )  
		{
			Destroy(gameObject); 
		
			int rand = Random.Range(1, 15);  
			    
			if(rand ==1)  
				Instantiate (pickup1, new Vector3 (transform.position.x, transform.position.y, transform.position.z), Quaternion.Euler (new Vector3 (0f, 0f, 0f))); 
			if(rand ==2)
				Instantiate (pickup2, new Vector3 (transform.position.x, transform.position.y, transform.position.z), Quaternion.Euler (new Vector3 (0f, 0f, 0f))); 
			if(rand ==3)
				Instantiate (pickup3, new Vector3 (transform.position.x, transform.position.y, transform.position.z), Quaternion.Euler (new Vector3 (0f, 0f, 0f))); 
			if(rand ==4)   
				Instantiate (pickup1, new Vector3 (transform.position.x, transform.position.y, transform.position.z), Quaternion.Euler (new Vector3 (0f, 0f, 0f))); 
		}    
	}
}
