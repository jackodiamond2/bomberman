﻿using UnityEngine;
using System.Collections;
using UnityEngine.UI;
//also used as managerScript 
public class cameraScript : MonoBehaviour {

	public GameObject player1, player2;
	public GameObject text; 
	UnityEngine.UI.Text cdown; 
	int token; 
	public static int remote1,remote2,trigger;   
	float timeLeft = 9.0f;
	// Use this for initialization
	void Start () {
		remote1 = 0;
		remote2 = 0;
		cdown = text.GetComponent<Text>();   
	}
	
	// Update is called once per frame
	void Update () { 
		float dist = Mathf.Pow (player1.transform.position.x - player2.transform.position.x, 2) + Mathf.Pow (player1.transform.position.y - player2.transform.position.y, 2);
		float meanx = player1.transform.position.x + player2.transform.position.x;
		meanx = meanx * 0.5f;
		float meany = player1.transform.position.y + player2.transform.position.y;
		meany = meany * 0.5f; 
	  



		if (dist < 300) {
			transform.position = new Vector3 (meanx, meany, -17f); 
		}
		if ((dist> 300) &&(dist < 400)){
			transform.position = new Vector3 (meanx, meany, -18f);   
		}
		if ((dist> 400) &&(dist < 600)){ 
			transform.position = new Vector3 (meanx, meany, -19f);  
		}
		if (dist> 600){   
			transform.position = new Vector3 (meanx, meany, -20f);     
		}

		 
		timeLeft -= Time.deltaTime;
		cdown.text =""+  Mathf.Round(timeLeft);
		if(timeLeft < 0)
		{
			Application.LoadLevel(1);    
		}


	
	}
}
