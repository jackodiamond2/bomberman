﻿using UnityEngine;
using System.Collections;

public class bombScript : MonoBehaviour {
	float TimeT ;
	public GameObject blast;


	// Use this for initialization
	void Start () {
		TimeT = 0f;
	
	}
	
	// Update is called once per frame
	void Update () {   
		TimeT += Time.deltaTime;
		if (cameraScript.remote1 == 0) {
			if (TimeT >= 3f) {
				Destroy (gameObject); 
				Instantiate (blast, new Vector3 (transform.position.x, transform.position.y, transform.position.z), Quaternion.Euler (new Vector3 (0f, 0f, 0f))); 
			}
		}
		if (cameraScript.remote1 == 1) {
			if(Input.GetKeyDown (KeyCode.L)){   
				cameraScript.remote1 = 0;
				Destroy (gameObject); 
				Instantiate (blast, new Vector3 (transform.position.x, transform.position.y, transform.position.z), Quaternion.Euler (new Vector3 (0f, 0f, 0f))); 
			}  
			if (TimeT >= 10f) {
				cameraScript.remote1 = 0;  
				Destroy (gameObject); 
				Instantiate (blast, new Vector3 (transform.position.x, transform.position.y, transform.position.z), Quaternion.Euler (new Vector3 (0f, 0f, 0f))); 
			}
		}

		if (cameraScript.trigger == 1) { 
			Destroy (gameObject); 
			cameraScript.trigger = 0;  
			Instantiate (blast, new Vector3 (transform.position.x, transform.position.y, transform.position.z), Quaternion.Euler (new Vector3 (0f, 0f, 0f))); 
		}    
	}  
}
