﻿using UnityEngine;
using System.Collections;

public class blastScript2 : MonoBehaviour { 
	float TimeT ;

	// Use this for initialization
	void Start () {
		if ((pickupScript1.p == 2) && (pickupScript1.longer == 1)) {
			TimeT = -0.5f; 
			pickupScript1.p = 0;
			 
		}
		else   
			TimeT = 0f;     

		cameraScript.trigger = 1; 
	} 
	
	// Update is called once per frame
	void Update () {
		TimeT += Time.deltaTime;  
		if (TimeT >= 0.5f) {
			movement2.temp2 = movement2.temp2 +1;    
			Destroy (gameObject);    
		}
	}
}
