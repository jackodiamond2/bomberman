﻿using UnityEngine;
using System.Collections;

public class movement1 : MonoBehaviour {

	public GameObject bomb,scoreBomb; 
	public static int temp,dead;
	public static float speed;
	// Use this for initialization
	void Start () {
		temp = 1;   
		speed = 0f;  
		dead = 0;
	} 
	 
	// Update is called once per frame
	void Update () { 
		if (Input.GetKey (KeyCode.DownArrow)) 
			transform.position = new Vector3 (transform.position.x, transform.position.y - .1f-speed, transform.position.z);
		if (Input.GetKey (KeyCode.UpArrow)) 
			transform.position = new Vector3(transform.position.x, transform.position.y + .1f+speed, transform.position.z);
		if (Input.GetKey (KeyCode.RightArrow)) 
			transform.position = new Vector3(transform.position.x +.1f+speed, transform.position.y, transform.position.z);
		if (Input.GetKey (KeyCode.LeftArrow)) 
			transform.position = new Vector3(transform.position.x - .1f+speed, transform.position.y , transform.position.z);
	
		if((Input.GetKeyDown (KeyCode.L))&&(temp>0)){ 
			cameraScript.trigger = 0;
			cameraScript.trigger = 0; 
			Instantiate (bomb, new Vector3 (transform.position.x, transform.position.y, transform.position.z+0.5f), Quaternion.Euler(new Vector3(0f,0f,0f))); 		 
			temp = temp - 1;   
		}  

		if (temp == 0) {
			scoreBomb.SetActive(false);      
		}
		if(temp>0) 
			scoreBomb.SetActive(true); 
	}

	private void OnCollisionEnter(Collision collision)
	{

		// You probably want a check here to make sure you're hitting a zombie
		// Note that this is not the best method for doing so.
		if ( collision.gameObject.tag == "blast" )  
		{
			dead = 1;   
			Destroy(gameObject);
			Application.LoadLevel (1);   
		} 
	}
}
