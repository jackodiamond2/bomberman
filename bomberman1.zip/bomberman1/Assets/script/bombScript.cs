﻿using UnityEngine;
using System.Collections;

public class bombScript : MonoBehaviour {
	float TimeT ;
	public GameObject blast;
	// Use this for initialization
	void Start () {
		TimeT = 0f;
	}
	
	// Update is called once per frame
	void Update () {
		TimeT += Time.deltaTime;
		if (TimeT >= 3f) {
			Destroy (gameObject); 
			Instantiate (blast, new Vector3 (transform.position.x, transform.position.y, transform.position.z), Quaternion.Euler(new Vector3(0f,0f,0f))); 
		}
	}
}
