﻿using UnityEngine;
using System.Collections;

public class blastScript : MonoBehaviour { 
	float TimeT ;
	// Use this for initialization
	void Start () {
		TimeT = 0f;
	}
	
	// Update is called once per frame
	void Update () {
		TimeT += Time.deltaTime;
		if (TimeT >= 0.5f)  
			Destroy (gameObject);   
	}
}
