﻿using UnityEngine;
using System.Collections;

public class movement1 : MonoBehaviour {

	public GameObject bomb;
	// Use this for initialization
	void Start () {
	
	}

	// Update is called once per frame
	void Update () {
		if (Input.GetKey (KeyCode.DownArrow)) 
			transform.position = new Vector3 (transform.position.x, transform.position.y - .1f, transform.position.z);
		if (Input.GetKey (KeyCode.UpArrow)) 
			transform.position = new Vector3(transform.position.x, transform.position.y + .1f, transform.position.z);
		if (Input.GetKey (KeyCode.RightArrow)) 
			transform.position = new Vector3(transform.position.x +.1f, transform.position.y, transform.position.z);
		if (Input.GetKey (KeyCode.LeftArrow)) 
			transform.position = new Vector3(transform.position.x - .1f, transform.position.y , transform.position.z);
	
		if(Input.GetKeyDown (KeyCode.L)){ 
			Instantiate (bomb, new Vector3 (transform.position.x, transform.position.y, transform.position.z+1f), Quaternion.Euler(new Vector3(0f,0f,0f))); 
		}
	}

	private void OnCollisionEnter(Collision collision)
	{

		// You probably want a check here to make sure you're hitting a zombie
		// Note that this is not the best method for doing so.
		if ( collision.gameObject.tag == "blast" )  
		{
			Destroy(gameObject);
		} 
	}
}
