﻿using UnityEngine;
using System.Collections;

public class enemyScript2 : MonoBehaviour {

	int rand;
	// Use this for initialization
	void Start () {       
		rand = 0;
	}
	
	// Update is called once per frame
	void Update () {
		

		if(rand ==0)
		transform.position = new Vector3 (transform.position.x - .1f, transform.position.y , transform.position.z);
		if(rand ==1)
		transform.position = new Vector3 (transform.position.x + .1f, transform.position.y , transform.position.z); 
	} 
	 
	private void OnCollisionEnter(Collision collision)
	{


		if (rand == 0) {
			rand = 1;
		}
		else {
	
			rand = 0; 
		}

		if ( collision.gameObject.tag == "blast" )  
		{

			Destroy(gameObject);
			 
		}   
	}

}
