﻿using UnityEngine;
using System.Collections;
using UnityEngine.UI;

public class pickupScript1 : MonoBehaviour {

	public int pickupNo;  
	public static int longer,p;
	public GameObject text; 
	UnityEngine.UI.Text score;

	// Use this for initialization
	void Start () {
		longer = 0;
		p = 0;

	 score = text.GetComponent<Text>(); 
		   
	}
	
	// Update is called once per frame 
	void Update () {
	
	}

	private void OnCollisionEnter(Collision collision)
	{

		// You probably want a check here to make sure you're hitting a zombie
		// Note that this is not the best method for doing so.
		if ( collision.gameObject.tag == "player1" )  
		{	    
			textScript.temp = 1;
			 
			if (pickupNo == 0) { 
				longer = 1;
				p = 1;
				score.text ="P1:longer bomb blast"; 
				text.SetActive (true);
			} 
			if (pickupNo == 1) {
				movement1.temp = movement1.temp + 1;
				score.text ="P1:+1 bomb";  
				text.SetActive (true);
			}
			if (pickupNo == 2) {
				movement1.speed = movement1.speed+ 0.01f;    
				score.text ="P1:faster speed";      
				text.SetActive (true);
			}
			if (pickupNo == 3) {
				cameraScript.remote1 = 1;   
				score.text ="P1:Remote Controlled Bomb";    
				text.SetActive (true);
			}  

			Destroy(gameObject); 

		} 
		if ( collision.gameObject.tag == "player2" )  
		{
			textScript.temp = 1; 
			 
			if (pickupNo == 0) {
				longer = 1;
				p = 2;  
				score.text ="P2:longer bomb blast";
				text.SetActive (true);  
			}
			if (pickupNo == 1) {
				movement2.temp2 = movement2.temp2 + 1;
				score.text ="P2:+1 bomb"; 
				text.SetActive (true);
			} 
			if (pickupNo == 2) {
				movement2.speed = movement2.speed+ 0.01f;    
				score.text ="P2:faster speed";    
				text.SetActive (true);  
			}
			if (pickupNo == 3) {
				cameraScript.remote2 = 1;  
				score.text ="P2:Remote Controlled Bomb";  
				text.SetActive (true); 
			}
			 
			GameObject.Destroy(gameObject); 
		} 
	}
}
