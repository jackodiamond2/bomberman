﻿using UnityEngine;
using System.Collections;

public class movement2 : MonoBehaviour {
	 
	public GameObject bomb,scoreBomb2;   
	public static int temp2,dead;
	public static float speed;
	Rigidbody rb;  
	// Use this for initialization
	void Start () {
		temp2 = 1;
		speed = 0f;
		dead = 0; 
		rb = GetComponent<Rigidbody>();

	} 
	 
	// Update is called once per frame
	void Update () {  
		if (Input.GetKey (KeyCode.S))  
			transform.position = new Vector3 (transform.position.x, transform.position.y - .1f-speed, transform.position.z);
		if (Input.GetKey (KeyCode.W)) 
			transform.position = new Vector3(transform.position.x, transform.position.y + .1f+speed, transform.position.z);
		if (Input.GetKey (KeyCode.D)) 
			transform.position = new Vector3(transform.position.x +.1f+speed, transform.position.y, transform.position.z);
		if (Input.GetKey (KeyCode.A)) 
			transform.position = new Vector3(transform.position.x - .1f+speed, transform.position.y , transform.position.z);
		if (!Input.anyKeyDown)
			rb.velocity = new Vector3(0f,0f,0f);    
			
		if((Input.GetKeyDown (KeyCode.Q)&&(temp2>0))){ 
			cameraScript.trigger = 0;  
			cameraScript.trigger = 0;     
			Instantiate (bomb, new Vector3 (transform.position.x, transform.position.y, transform.position.z+0.5f), Quaternion.Euler(new Vector3(0f,0f,0f))); 
			scoreBomb2.SetActive(false);  
			temp2 = temp2- 1;   
		} 

		if (temp2 == 0) {
			scoreBomb2.SetActive(false);         
		}   
		if(temp2>0)
			scoreBomb2.SetActive(true);  
	}

	private void OnCollisionEnter(Collision collision)
	{

		// You probably want a check here to make sure you're hitting a zombie
		// Note that this is not the best method for doing so.
		if (( collision.gameObject.tag == "blast" )||(collision.gameObject.tag=="enemy"))
		{
			dead = 1;
			Destroy(gameObject);  
			Application.LoadLevel (1); 
		} 
	} 
}
