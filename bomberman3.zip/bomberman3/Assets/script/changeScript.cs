﻿using UnityEngine;
using System.Collections;

public class changeScript : MonoBehaviour {
	float TimeT ;
	int rand;
	  
	// Use this for initialization
	void Start () {
		TimeT = 0;  
		rand = 0;   
	}
	
	// Update is called once per frame
	void Update () {
		TimeT += Time.deltaTime;  

		if (TimeT >Random.Range(1f,15f)) {
			TimeT = 0;
			if (rand == 0) {
				change1 ();
				rand = 1;
			} else {
				change2 ();  
				rand = 0; 
			}     
		}
	}

	void change1(){
		Destroy(gameObject.GetComponent("enemyScript"));  
		gameObject.AddComponent<enemyScript2>();         
	}

	void change2(){
		Destroy(gameObject.GetComponent("enemyScript2"));  
		gameObject.AddComponent<enemyScript>();             
	}  
}
