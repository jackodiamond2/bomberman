﻿using UnityEngine;
using System.Collections;

public class textScript : MonoBehaviour {

	public static int temp;
	float TimeT;
	// Use this for initialization
	void Start () {
		
		TimeT = 0;     
	}
	
	// Update is called once per frame
	void Update () {   
		if(temp ==1)
			TimeT += Time.deltaTime; 
		
		if (TimeT > 3f) {
			gameObject.SetActive (false);
			TimeT = 0;  
			temp = 0; 
		}
	}
}
